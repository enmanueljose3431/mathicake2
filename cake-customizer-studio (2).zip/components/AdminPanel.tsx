
import React, { useState, useEffect } from 'react';
import { AppConfig, Order, CakeSize, Flavor, Filling, DecorationInfo, CakeColor } from '../types';

interface AdminPanelProps {
  config: AppConfig;
  onUpdateConfig: (newConfig: AppConfig) => void;
  orders: Order[];
  onDeleteOrder: (id: string) => void;
  onUpdateOrderStatus: (id: string, status: 'PENDING' | 'COMPLETED') => void;
  onClearOrders: () => void;
  onExit: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ config, onUpdateConfig, orders, onDeleteOrder, onUpdateOrderStatus, onClearOrders, onExit }) => {
  const [activeTab, setActiveTab] = useState<'ORDERS' | 'SIZES' | 'FLAVORS' | 'DECORATIONS' | 'COLORS' | 'PRICES' | 'PAYMENTS' | 'SETTINGS'>('ORDERS');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (isSaving) {
      const timer = setTimeout(() => setIsSaving(false), 1500);
      return () => clearTimeout(timer);
    }
  }, [isSaving]);

  const updateConfig = (newPart: Partial<AppConfig>) => {
    setIsSaving(true);
    onUpdateConfig({ ...config, ...newPart });
  };

  // --- MOLDES ---
  const updateSize = (id: string, f: keyof CakeSize, v: any) => {
    updateConfig({ sizes: config.sizes.map(s => s.id === id ? { ...s, [f]: v } : s) });
  };
  const addSize = () => {
    const n: CakeSize = { id: `sz_${Date.now()}`, diameter: 14, heightType: 'SHORT', portions: '8 Porc', basePrice: 20, costMultiplier: 1.0 };
    updateConfig({ sizes: [...config.sizes, n] });
  };
  const removeSize = (id: string) => {
    updateConfig({ sizes: config.sizes.filter(s => s.id !== id) });
  };

  // --- SABORES Y RELLENOS ---
  const updateFlavor = (id: string, f: keyof Flavor, v: any) => {
    updateConfig({ flavors: config.flavors.map(fl => fl.id === id ? { ...fl, [f]: v } : fl) });
  };
  const addFlavor = () => {
    const n: Flavor = { id: `fl_${Date.now()}`, name: 'Nuevo', color: '#FFFFFF', priceModifier: 0 };
    updateConfig({ flavors: [...config.flavors, n] });
  };
  const removeFlavor = (id: string) => {
    updateConfig({ flavors: config.flavors.filter(f => f.id !== id) });
  };

  const updateFilling = (id: string, f: keyof Filling, v: any) => {
    updateConfig({ fillings: config.fillings.map(fill => fill.id === id ? { ...fill, [f]: v } : fill) });
  };
  const addFilling = () => {
    const n: Filling = { id: `fill_${Date.now()}`, name: 'Nuevo', color: '#FFFFFF', priceModifier: 0 };
    updateConfig({ fillings: [...config.fillings, n] });
  };
  const removeFilling = (id: string) => {
    updateConfig({ fillings: config.fillings.filter(f => f.id !== id) });
  };

  // --- COLORES ---
  const addColor = () => {
    const n: CakeColor = { name: 'Nuevo Color', hex: '#E2E2E2', isSaturated: false, priceModifier: 0 };
    updateConfig({ colors: [...config.colors, n] });
  };
  const removeColor = (idx: number) => {
    updateConfig({ colors: config.colors.filter((_, i) => i !== idx) });
  };
  const updateColor = (idx: number, field: keyof CakeColor, value: any) => {
    const next = [...config.colors];
    next[idx] = { ...next[idx], [field]: value };
    updateConfig({ colors: next });
  };

  // --- DECORACIONES ---
  const updateDecoration = (id: string, f: keyof DecorationInfo, v: any) => {
    const next = { ...config.decorations };
    next[id] = { ...next[id], [f]: v };
    updateConfig({ decorations: next });
  };

  const handleImageUpload = (id: string, type: 'flavor' | 'filling' | 'decoration', e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const r = new FileReader();
      r.onloadend = () => {
        const b64 = r.result as string;
        if (type === 'flavor') updateFlavor(id, 'textureUrl', b64);
        else if (type === 'filling') updateFilling(id, 'textureUrl', b64);
        else if (type === 'decoration') updateDecoration(id, 'textureUrl', b64);
      };
      r.readAsDataURL(file);
    }
  };

  const menuItems = [
    { id: 'ORDERS', label: 'Ventas', icon: 'analytics' },
    { id: 'SIZES', label: 'Moldes', icon: 'straighten' },
    { id: 'FLAVORS', label: 'Sabores/Rellenos', icon: 'restaurant_menu' },
    { id: 'DECORATIONS', label: 'Estilos', icon: 'auto_fix_high' },
    { id: 'COLORS', label: 'Colores', icon: 'palette' },
    { id: 'PRICES', label: 'Precios Extras', icon: 'sell' },
    { id: 'PAYMENTS', label: 'Banco/Pagos', icon: 'account_balance' },
    { id: 'SETTINGS', label: 'Marca/Logo', icon: 'settings' },
  ];

  return (
    <div className="flex h-screen bg-slate-50 font-quicksand overflow-hidden">
      <aside className={`fixed inset-y-0 left-0 w-72 bg-slate-900 z-[120] transition-transform ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 lg:static flex flex-col shadow-2xl`}>
        <div className="p-8 border-b border-slate-800 text-white font-display uppercase tracking-widest flex items-center gap-3">
          <span className="material-icons-round text-primary">cake</span>
          Admin Mathi
        </div>
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto no-scrollbar">
          {menuItems.map(item => (
            <button key={item.id} onClick={() => { setActiveTab(item.id as any); setIsMobileMenuOpen(false); }} className={`w-full flex items-center gap-4 px-6 py-4 rounded-xl transition-all ${activeTab === item.id ? 'bg-primary text-white shadow-xl scale-105' : 'text-slate-400 hover:bg-slate-800'}`}>
              <span className="material-icons-round text-xl">{item.icon}</span>
              <span className="text-[10px] font-black uppercase tracking-widest">{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="p-6 border-t border-slate-800">
          <button onClick={onExit} className="w-full bg-slate-800 hover:bg-red-600 text-white py-4 rounded-xl font-black uppercase text-xs transition-colors">Cerrar Sesión</button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-20 bg-white border-b border-slate-200 px-6 md:px-10 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4">
             <button onClick={() => setIsMobileMenuOpen(true)} className="lg:hidden p-2 text-slate-600"><span className="material-icons-round">menu</span></button>
             <h2 className="text-lg font-black text-slate-800 uppercase tracking-tighter">{menuItems.find(i => i.id === activeTab)?.label}</h2>
          </div>
          {isSaving && (
            <div className="flex items-center gap-2 text-primary font-black uppercase text-[10px] animate-pulse">
              <span className="material-icons-round text-sm">sync</span>
              Sincronizando...
            </div>
          )}
        </header>

        <div className="flex-1 overflow-y-auto p-6 md:p-10 no-scrollbar bg-slate-50/30">
          <div className="max-w-6xl mx-auto space-y-10 pb-20">

            {activeTab === 'ORDERS' && (
              <div className="space-y-4">
                {orders.length === 0 ? (
                  <div className="bg-white p-20 rounded-3xl border-2 border-dashed border-slate-200 text-center">
                    <p className="text-slate-400 font-black uppercase text-[10px] tracking-widest">Aún no hay pedidos registrados</p>
                  </div>
                ) : (
                  orders.map(o => (
                    <div key={o.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-6 hover:shadow-md transition-all">
                      <div className="w-16 h-16 bg-slate-50 rounded-xl flex items-center justify-center font-display text-primary border text-xl shrink-0">{o.id.slice(-4)}</div>
                      <div className="flex-1">
                        <h4 className="font-black text-slate-800 uppercase text-sm">{o.customerName}</h4>
                        <p className="text-[9px] text-slate-400 font-bold mb-2">{o.date}</p>
                        <p className="text-[11px] text-slate-600 whitespace-pre-line leading-relaxed">{o.details}</p>
                      </div>
                      <div className="text-right flex flex-col items-end gap-3 shrink-0">
                        <div className="flex flex-col items-end">
                            <p className="text-3xl font-display text-primary">${o.total.toFixed(2)}</p>
                            <span className={`text-[8px] font-black uppercase px-3 py-1 rounded-full border ${o.status === 'COMPLETED' ? 'bg-green-50 text-green-600 border-green-100' : 'bg-amber-50 text-amber-600 border-amber-100'}`}>
                                {o.status === 'COMPLETED' ? 'Entregado' : 'Pendiente'}
                            </span>
                        </div>
                        <div className="flex flex-col gap-2 w-full md:w-32">
                           {o.status === 'PENDING' && (
                             <button 
                                onClick={() => onUpdateOrderStatus(o.id, 'COMPLETED')}
                                className="flex items-center justify-center gap-2 bg-green-500 hover:bg-green-600 text-white py-2 rounded-xl text-[9px] font-black uppercase transition-all shadow-md active:scale-95"
                             >
                                <span className="material-icons-round text-xs">check_circle</span>
                                ENTREGADO
                             </button>
                           )}
                           <button 
                             onClick={(e) => {
                               e.stopPropagation();
                               onDeleteOrder(o.id);
                             }}
                             className="flex items-center justify-center gap-2 bg-slate-100 hover:bg-red-600 text-slate-400 hover:text-white py-2.5 rounded-xl text-[9px] font-black uppercase transition-all active:scale-95 shadow-sm border border-slate-200"
                           >
                             <span className="material-icons-round text-sm">delete_forever</span>
                             ELIMINAR
                           </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {activeTab === 'SIZES' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <button onClick={addSize} className="bg-primary/5 border-2 border-dashed border-primary/20 p-10 rounded-3xl flex flex-col items-center justify-center gap-2 hover:bg-primary/10 transition-all min-h-[150px]">
                  <span className="material-icons-round text-primary text-5xl">add_circle</span>
                  <span className="text-[10px] font-black uppercase text-primary">Nuevo Molde</span>
                </button>
                {config.sizes.map(s => (
                  <div key={s.id} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4 relative group">
                    <button onClick={() => removeSize(s.id)} className="absolute top-4 right-4 text-slate-300 hover:text-red-500"><span className="material-icons-round text-sm">delete</span></button>
                    <div className="grid grid-cols-2 gap-4">
                       <div>
                         <label className="text-[8px] font-black uppercase text-slate-400">Diámetro</label>
                         <input type="number" className="w-full bg-slate-50 rounded-xl p-3 font-bold border-none text-sm" value={s.diameter} onChange={(e) => updateSize(s.id, 'diameter', parseInt(e.target.value))} />
                       </div>
                       <div>
                         <label className="text-[8px] font-black uppercase text-slate-400">Altura</label>
                         <select className="w-full bg-slate-50 rounded-xl p-3 text-[10px] font-bold border-none" value={s.heightType} onChange={(e) => updateSize(s.id, 'heightType', e.target.value)}>
                            <option value="SHORT">BAJO</option><option value="TALL">ALTO</option>
                         </select>
                       </div>
                    </div>
                    <div>
                      <label className="text-[8px] font-black uppercase text-slate-400">Precio Base ($)</label>
                      <input type="number" className="w-full bg-slate-50 rounded-xl p-3 font-bold border-none text-sm" value={s.basePrice} onChange={(e) => updateSize(s.id, 'basePrice', parseFloat(e.target.value))} />
                    </div>
                    <div>
                      <label className="text-[8px] font-black uppercase text-slate-400">Factor Conversión</label>
                      <input type="number" step="0.1" className="w-full bg-slate-50 rounded-xl p-3 font-bold border-none text-sm" value={s.costMultiplier} onChange={(e) => updateSize(s.id, 'costMultiplier', parseFloat(e.target.value))} />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'FLAVORS' && (
              <div className="space-y-10">
                <section>
                  <div className="flex justify-between items-center mb-6">
                     <h3 className="text-xs font-black uppercase text-slate-500">Sabores de Bizcocho</h3>
                     <button onClick={addFlavor} className="bg-primary text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase">Añadir Sabor</button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {config.flavors.map(f => (
                      <div key={f.id} className="bg-white p-6 rounded-3xl border border-slate-200 flex items-center gap-6 group">
                         <div className="relative w-16 h-16 rounded-2xl overflow-hidden border border-slate-100 shrink-0">
                            {f.textureUrl ? <img src={f.textureUrl} className="w-full h-full object-cover" /> : <div className="w-full h-full" style={{ backgroundColor: f.color }} />}
                            <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => handleImageUpload(f.id, 'flavor', e)} />
                         </div>
                         <div className="flex-1">
                            <input type="text" className="w-full bg-transparent font-black text-sm border-none p-0 mb-1" value={f.name} onChange={(e) => updateFlavor(f.id, 'name', e.target.value)} />
                            <div className="flex items-center gap-2">
                               <span className="text-[8px] font-bold uppercase text-slate-400">Extra:</span>
                               <input type="number" className="w-16 bg-slate-50 rounded-lg p-1 text-[10px] font-bold border-none" value={f.priceModifier} onChange={(e) => updateFlavor(f.id, 'priceModifier', parseFloat(e.target.value))} />
                            </div>
                         </div>
                         <button onClick={() => removeFlavor(f.id)} className="text-slate-200 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"><span className="material-icons-round">delete</span></button>
                      </div>
                    ))}
                  </div>
                </section>

                <section>
                  <div className="flex justify-between items-center mb-6">
                     <h3 className="text-xs font-black uppercase text-slate-500">Rellenos Disponibles</h3>
                     <button onClick={addFilling} className="bg-primary text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase">Añadir Relleno</button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {config.fillings.map(f => (
                      <div key={f.id} className="bg-white p-6 rounded-3xl border border-slate-200 flex items-center gap-6 group">
                         <div className="relative w-16 h-16 rounded-full overflow-hidden border border-slate-100 shrink-0">
                            {f.textureUrl ? <img src={f.textureUrl} className="w-full h-full object-cover" /> : <div className="w-full h-full" style={{ backgroundColor: f.color }} />}
                            <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => handleImageUpload(f.id, 'filling', e)} />
                         </div>
                         <div className="flex-1">
                            <input type="text" className="w-full bg-transparent font-black text-sm border-none p-0 mb-1" value={f.name} onChange={(e) => updateFilling(f.id, 'name', e.target.value)} />
                            <div className="flex items-center gap-2">
                               <span className="text-[8px] font-bold uppercase text-slate-400">Extra:</span>
                               <input type="number" className="w-16 bg-slate-50 rounded-lg p-1 text-[10px] font-bold border-none" value={f.priceModifier} onChange={(e) => updateFilling(f.id, 'priceModifier', parseFloat(e.target.value))} />
                            </div>
                         </div>
                         <button onClick={() => removeFilling(f.id)} className="text-slate-200 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"><span className="material-icons-round">delete</span></button>
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            )}

            {activeTab === 'DECORATIONS' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {Object.values(config.decorations).map((dec: DecorationInfo) => (
                  <div key={dec.id} className="bg-white p-8 rounded-[3rem] border border-slate-200 shadow-sm space-y-6">
                     <div className="flex items-center gap-6">
                        <div className="relative w-24 h-24 rounded-[2rem] overflow-hidden bg-slate-100 border-4 border-white shadow-md shrink-0">
                           {dec.textureUrl ? <img src={dec.textureUrl} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-slate-300"><span className="material-icons-round text-4xl">broken_image</span></div>}
                           <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => handleImageUpload(dec.id, 'decoration', e)} />
                        </div>
                        <div className="flex-1">
                           <input type="text" className="w-full bg-transparent font-display text-xl border-none p-0 mb-2" value={dec.label} onChange={(e) => updateDecoration(dec.id, 'label', e.target.value)} />
                           <div className="flex items-center gap-4">
                              <label className="text-[10px] font-black uppercase text-slate-400">Suplemento:</label>
                              <div className="bg-slate-50 px-4 py-2 rounded-2xl flex items-center gap-2">
                                 <span className="text-primary font-bold">$</span>
                                 <input type="number" className="w-16 bg-transparent border-none font-black text-sm p-0" value={dec.priceModifier} onChange={(e) => updateDecoration(dec.id, 'priceModifier', parseFloat(e.target.value))} />
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'COLORS' && (
               <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm">
                  <div className="flex justify-between items-center mb-8">
                     <h3 className="text-sm font-black uppercase text-slate-800">Paleta de Colores de Crema</h3>
                     <button onClick={addColor} className="bg-primary text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase flex items-center gap-2">
                        <span className="material-icons-round text-sm">add</span>
                        Añadir Color
                     </button>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                    {config.colors.map((c, idx) => (
                       <div key={idx} className="flex flex-col items-center gap-3 p-5 bg-slate-50 rounded-3xl relative group shadow-sm border border-slate-100">
                          <button onClick={() => removeColor(idx)} className="absolute top-2 right-2 text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100">
                             <span className="material-icons-round text-sm">close</span>
                          </button>
                          <input type="color" className="w-16 h-16 rounded-full border-4 border-white shadow-md p-0 overflow-hidden cursor-pointer" value={c.hex} onChange={(e) => updateColor(idx, 'hex', e.target.value)} />
                          <input type="text" className="w-full text-center bg-transparent border-none p-0 font-black text-[10px] uppercase tracking-wider" value={c.name} onChange={(e) => updateColor(idx, 'name', e.target.value)} />
                          
                          <div className="flex flex-col gap-2 w-full pt-2 border-t border-slate-200">
                            <div className="flex items-center justify-between">
                               <span className="text-[8px] font-black uppercase text-slate-400">Incremento $</span>
                               <input type="number" step="0.5" className="w-12 bg-white border-none rounded p-1 text-[9px] font-bold text-center" value={c.priceModifier || 0} onChange={(e) => updateColor(idx, 'priceModifier', parseFloat(e.target.value))} />
                            </div>
                            <label className="flex items-center justify-between cursor-pointer">
                               <span className="text-[8px] font-black uppercase text-slate-400">Saturado</span>
                               <input type="checkbox" className="rounded text-primary focus:ring-primary w-3 h-3" checked={c.isSaturated} onChange={(e) => updateColor(idx, 'isSaturated', e.target.checked)} />
                            </label>
                          </div>
                       </div>
                    ))}
                  </div>
               </div>
            )}

            {activeTab === 'PRICES' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <section className="bg-white p-8 rounded-[3rem] border border-slate-200">
                  <h3 className="text-xs font-black uppercase text-slate-800 mb-6">Precios de Toppers</h3>
                  <div className="space-y-4">
                    {Object.keys(config.topperPrices).map(k => (
                      <div key={k} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                         <span className="text-[10px] font-black uppercase text-slate-600">{k === 'none' ? 'Sin Topper' : k === 'generic' ? 'Genérico' : k === 'personalized' ? 'Personalizado' : 'Topper+Piezas'}</span>
                         <div className="flex items-center gap-2">
                            <span className="text-primary font-bold">$</span>
                            <input type="number" className="w-20 bg-white border-none rounded-lg p-2 font-bold text-sm" value={config.topperPrices[k]} onChange={(e) => {
                               const next = { ...config.topperPrices, [k]: parseFloat(e.target.value) };
                               updateConfig({ topperPrices: next });
                            }} />
                         </div>
                      </div>
                    ))}
                  </div>
                </section>
                <section className="bg-white p-8 rounded-[3rem] border border-slate-200">
                   <h3 className="text-xs font-black uppercase text-slate-800 mb-6">Otros Suplementos</h3>
                   <div className="space-y-6">
                      <div className="flex items-center justify-between">
                         <span className="text-[10px] font-black uppercase text-slate-600">Esferas Decorativas</span>
                         <input type="number" className="w-24 bg-slate-50 border-none rounded-xl p-3 font-bold text-sm" value={config.spheresPrice} onChange={(e) => updateConfig({ spheresPrice: parseFloat(e.target.value) })} />
                      </div>
                      <div className="flex items-center justify-between">
                         <span className="text-[10px] font-black uppercase text-slate-600">Recargo Color Saturado</span>
                         <input type="number" className="w-24 bg-slate-50 border-none rounded-xl p-3 font-bold text-sm" value={config.saturatedColorSurcharge} onChange={(e) => updateConfig({ saturatedColorSurcharge: parseFloat(e.target.value) })} />
                      </div>
                   </div>
                </section>
              </div>
            )}

            {activeTab === 'PAYMENTS' && (
               <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm max-w-3xl">
                  <h3 className="text-sm font-black uppercase text-slate-800 mb-8">Datos Bancarios para Clientes</h3>
                  <div className="space-y-6">
                     {Object.keys(config.paymentDetails).map(k => (
                       <div key={k} className="flex flex-col gap-2">
                          <label className="text-[9px] font-black uppercase text-slate-400 ml-2">{k}</label>
                          <input type="text" className="w-full bg-slate-50 border-none rounded-2xl p-4 font-bold text-sm" value={(config.paymentDetails as any)[k]} onChange={(e) => {
                             const next = { ...config.paymentDetails, [k]: e.target.value };
                             updateConfig({ paymentDetails: next });
                          }} />
                       </div>
                     ))}
                  </div>
               </div>
            )}

            {activeTab === 'SETTINGS' && (
               <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm max-w-3xl">
                  <h3 className="text-sm font-black uppercase text-slate-800 mb-8">Ajustes de Marca y Tema</h3>
                  <div className="space-y-6">
                     <div className="flex items-center gap-8 p-6 bg-slate-50 rounded-3xl">
                        <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center border-2 border-dashed border-slate-300 relative overflow-hidden shrink-0">
                           {config.appTheme.logoUrl ? <img src={config.appTheme.logoUrl} className="w-full h-full object-contain" /> : <span className="material-icons-round text-slate-300">add_photo_alternate</span>}
                           <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                 const r = new FileReader();
                                 r.onloadend = () => updateConfig({ appTheme: { ...config.appTheme, logoUrl: r.result as string } });
                                 r.readAsDataURL(file);
                              }
                           }} />
                        </div>
                        <div className="flex-1">
                           <label className="text-[9px] font-black uppercase text-slate-400">Nombre de la Pastelería</label>
                           <input type="text" className="w-full bg-transparent font-display text-2xl border-none p-0" value={config.appTheme.brandName} onChange={(e) => updateConfig({ appTheme: { ...config.appTheme, brandName: e.target.value } })} />
                        </div>
                     </div>

                     <div className="grid grid-cols-2 gap-4">
                        <div className="flex flex-col gap-2">
                           <label className="text-[9px] font-black uppercase text-slate-400 ml-2">WhatsApp Ventas</label>
                           <input type="text" className="w-full bg-slate-50 border-none rounded-2xl p-4 font-bold text-sm" value={config.appTheme.whatsappNumber} onChange={(e) => updateConfig({ appTheme: { ...config.appTheme, whatsappNumber: e.target.value } })} />
                        </div>
                        <div className="flex flex-col gap-2">
                           <label className="text-[9px] font-black uppercase text-slate-400 ml-2">Color Primario</label>
                           <input type="color" className="w-full h-12 bg-slate-50 border-none rounded-2xl p-1 cursor-pointer" value={config.appTheme.primaryColor} onChange={(e) => updateConfig({ appTheme: { ...config.appTheme, primaryColor: e.target.value } })} />
                        </div>
                     </div>
                  </div>
               </div>
            )}

          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminPanel;