
import React, { useState, useCallback, useEffect } from 'react';
import { Step, AppState, AppConfig, Order, CakeSize, Flavor, Filling } from './types';
import { CAKE_SIZES, FLAVORS, FILLINGS, DECORATIONS, TOPPER_PRICES, SPHERES_PRICE, CAKE_COLORS, SATURATED_COLOR_SURCHARGE } from './constants';
import SizeStep from './components/SizeStep';
import FlavorStep from './components/FlavorStep';
import DecorationStep from './components/DecorationStep';
import PersonalizationStep from './components/PersonalizationStep';
import SummaryStep from './components/SummaryStep';
import PaymentStep from './components/PaymentStep';
import SuccessStep from './components/SuccessStep';
import AdminLogin from './components/AdminLogin';
import AdminPanel from './components/AdminPanel';

// Firebase imports
import { db } from './firebase';
import { collection, onSnapshot, doc, setDoc, getDoc, deleteDoc, updateDoc } from 'firebase/firestore';

const DEFAULT_CONFIG: AppConfig = {
  sizes: CAKE_SIZES,
  flavors: FLAVORS,
  fillings: FILLINGS,
  colors: CAKE_COLORS.map(c => ({ ...c, priceModifier: 0 })),
  decorations: DECORATIONS,
  topperPrices: TOPPER_PRICES,
  spheresPrice: SPHERES_PRICE,
  saturatedColorSurcharge: SATURATED_COLOR_SURCHARGE,
  coverageSurcharges: { chantilly: 0, chocolate: 5, arequipe: 4 },
  paymentDetails: {
    bankName: "Banco de Venezuela",
    accountHolder: "Tu Nombre Aquí",
    zelleEmail: "tu@correo.com",
    taxId: "V-00000000",
    exchangeRateNote: "Tasa BCV del día"
  },
  appTheme: {
    brandName: "MathiCake Studio",
    whatsappNumber: "584240000000",
    primaryColor: "#E31C58",
    secondaryColor: "#FFEB3B",
    backgroundColor: "#FFFBF2",
    textColor: "#000000",
    surfaceColor: "#FFFFFF"
  }
};

const App: React.FC = () => {
  const [config, setConfig] = useState<AppConfig>(DEFAULT_CONFIG);
  const [orders, setOrders] = useState<Order[]>([]);
  const [firebaseError, setFirebaseError] = useState<string | null>(null);

  // --- NAVEGACIÓN Y ESTADO ---
  const navigateTo = (step: Step) => setState(prev => ({ ...prev, step }));
  const updateAppState = (updates: Partial<AppState>) => setState(prev => ({ ...prev, ...updates }));
  const resetApp = () => setState(prev => ({ ...prev, step: 'SIZE' }));

  const handleSelectSize = (s: CakeSize) => updateAppState({ selectedSize: s });
  const handleGoToFlavor = () => navigateTo('FLAVOR');
  const handleGoToAdminLogin = () => navigateTo('ADMIN_LOGIN');
  const handleSelectFlavor = (f: Flavor) => updateAppState({ selectedFlavor: f });
  const handleSelectFilling = (fill: Filling) => updateAppState({ selectedFilling: fill });
  const handleGoToDecoration = () => navigateTo('DECORATION');
  const handleGoToSize = () => navigateTo('SIZE');
  const handleCustomFillingChange = (v: string) => updateAppState({ customFilling: v });
  const handleUpdateDecoration = (d: Partial<AppState>) => updateAppState(d);
  const handleGoToPersonalization = () => navigateTo('PERSONALIZATION');
  const handleUpdatePersonalization = (d: Partial<AppState>) => updateAppState(d);
  const handleGoToSummary = () => navigateTo('SUMMARY');
  const handleUpdateSummary = (d: Partial<AppState>) => updateAppState(d);
  const handleGoToPayment = () => navigateTo('PAYMENT');
  const handleUpdatePayment = (d: any) => updateAppState(d);
  const handleLoginSuccess = () => navigateTo('ADMIN_PANEL');

  // --- GESTIÓN DE PEDIDOS ---
  const handleDeleteOrder = async (orderId: string) => {
    if (!db) return;
    
    // Alerta de confirmación inmediata
    if (window.confirm(`¿Seguro que deseas ELIMINAR permanentemente la orden ${orderId}?`)) {
      try {
        console.log(`Intentando eliminar orden: ${orderId}`);
        
        // 1. ELIMINACIÓN OPTIMISTA (Desaparece de inmediato de la UI local)
        setOrders(prev => prev.filter(o => o.id !== orderId));
        
        // 2. ELIMINACIÓN REAL EN FIRESTORE
        const orderRef = doc(db, "orders", orderId);
        await deleteDoc(orderRef);
        console.log("Orden eliminada exitosamente en Firestore");
      } catch (e: any) {
        console.error("Error crítico al eliminar pedido:", e);
        alert(`No se pudo eliminar el pedido de la base de datos: ${e.message}`);
      }
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: 'PENDING' | 'COMPLETED') => {
    if (!db) return;
    try {
      const orderRef = doc(db, "orders", orderId);
      await updateDoc(orderRef, { status });
    } catch (e: any) {
      console.error("Error al actualizar estado:", e);
      alert(`Error: ${e.message}`);
    }
  };

  // --- FIREBASE SYNC ---
  useEffect(() => {
    if (!db) return;
    const configDocRef = doc(db, "settings", "appConfig");
    
    const initConfig = async () => {
      try {
        const docSnap = await getDoc(configDocRef);
        if (docSnap.exists()) {
          setConfig({ ...DEFAULT_CONFIG, ...docSnap.data() } as AppConfig);
        } else {
          await setDoc(configDocRef, DEFAULT_CONFIG);
        }
      } catch (e: any) {
        if (e.code === 'permission-denied') setFirebaseError("Acceso denegado a Firestore");
      }
    };
    initConfig();

    const unsubscribeConfig = onSnapshot(configDocRef, (docSnap) => {
      if (docSnap.exists()) setConfig(prev => ({ ...prev, ...docSnap.data() }));
    });

    const unsubscribeOrders = onSnapshot(collection(db, "orders"), (snapshot) => {
      const remoteOrders: Order[] = [];
      snapshot.forEach((doc) => { remoteOrders.push({ ...doc.data(), id: doc.id } as Order); });
      // Ordenar por fecha descendente
      remoteOrders.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setOrders(remoteOrders);
    });

    return () => { unsubscribeConfig(); unsubscribeOrders(); };
  }, []);

  // --- THEME ---
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--primary-color', config.appTheme.primaryColor);
    root.style.setProperty('--secondary-color', config.appTheme.secondaryColor);
    root.style.setProperty('--bg-color', config.appTheme.backgroundColor);
    root.style.setProperty('--text-color', config.appTheme.textColor);
    root.style.setProperty('--surface-color', config.appTheme.surfaceColor);
  }, [config.appTheme]);

  const [state, setState] = useState<AppState>({
    step: 'SIZE',
    selectedSize: config.sizes[1],
    selectedFlavor: config.flavors[0],
    selectedFilling: config.fillings[1],
    selectedDecoration: 'liso',
    cakeColors: ['#FFFFFF'],
    topperType: 'none',
    hasSpheres: false,
    theme: '',
    birthdayName: '',
    birthdayAge: '',
    specialRequirements: '',
    referenceImage: null,
    paymentProof: null,
    paymentReference: '',
    amountBs: '',
    deliveryMethod: 'PICKUP',
    deliveryDate: '',
    deliveryTime: '',
    coverageType: 'chantilly',
    totalPrice: 45,
    customFilling: '',
    paymentStrategy: 'FIFTY_PERCENT',
  });

  const calculateTotal = useCallback(() => {
    const size = config.sizes.find(s => s.id === state.selectedSize?.id) || config.sizes[0];
    const flavor = config.flavors.find(f => f.id === state.selectedFlavor?.id) || config.flavors[0];
    const filling = config.fillings.find(f => f.id === state.selectedFilling?.id) || config.fillings[0];
    const decor = config.decorations[state.selectedDecoration] || { priceModifier: 0 };
    const factor = size.costMultiplier || 1.0;
    
    let total = size.basePrice + (flavor.priceModifier * factor) + (filling.priceModifier * factor) + (decor.priceModifier * factor) + (config.coverageSurcharges[state.coverageType] * factor) + (config.topperPrices[state.topperType] || 0);
    
    if (state.hasSpheres) total += (config.spheresPrice * factor);
    
    const colorObjs = state.cakeColors.map(hex => config.colors.find(c => c.hex === hex));
    
    // Recargo por color saturado
    const hasSaturated = colorObjs.some(c => c?.isSaturated);
    if (hasSaturated) total += (config.saturatedColorSurcharge * factor);
    
    // Recargo por color individual
    const colorPriceSum = colorObjs.reduce((sum, c) => sum + (c?.priceModifier || 0), 0);
    total += (colorPriceSum * factor);
    
    return total;
  }, [state, config]);

  useEffect(() => {
    setState(prev => ({ ...prev, totalPrice: calculateTotal() }));
  }, [state.selectedSize, state.selectedFlavor, state.selectedFilling, state.selectedDecoration, state.coverageType, state.topperType, state.hasSpheres, state.cakeColors, config, calculateTotal]);

  const handleUpdateConfig = async (newConfig: AppConfig) => {
    setConfig(newConfig);
    if (db) await setDoc(doc(db, "settings", "appConfig"), newConfig);
  };

  const handleFinalizeOrder = async () => {
    const simpleId = Math.random().toString(36).substr(2, 6).toUpperCase();
    try {
      const decorLabel = config.decorations[state.selectedDecoration]?.label || 'Liso';
      const colorNames = state.cakeColors.map(hex => config.colors.find(c => c.hex === hex)?.name || 'Personalizado').join(', ');
      const detailedInfo = `🎂 PASTEL ${state.selectedSize?.diameter}cm\n🍰 Bizcocho: ${state.selectedFlavor?.name}\n🍦 Relleno: ${state.selectedFilling?.id === 'others' ? state.customFilling : state.selectedFilling?.name}\n✨ Estilo: ${decorLabel}\n🎨 Colores: ${colorNames}\n🎯 Cobertura: ${state.coverageType.toUpperCase()}\n🚀 Extras: ${state.topperType !== 'none' ? 'Topper ' + state.topperType : 'Sin Topper'}${state.hasSpheres ? ', con Esferas' : ''}\n🎉 Temática: ${state.theme}\n📍 Entrega: ${state.deliveryMethod} - ${state.deliveryDate}`;
      const newOrder: Order = { id: simpleId, date: new Date().toLocaleString(), customerName: state.birthdayName || 'Cliente Web', details: detailedInfo, total: state.totalPrice, status: 'PENDING' };
      if (db) await setDoc(doc(db, "orders", simpleId), newOrder);
      window.open(`https://wa.me/${config.appTheme.whatsappNumber}?text=${encodeURIComponent(`🎂 *NUEVO PEDIDO* (Ref: ${simpleId})\n\n${detailedInfo}\n\n💰 Total: $${state.totalPrice.toFixed(2)}`)}`, '_blank');
      setState(prev => ({ ...prev, step: 'SUCCESS', lastOrderId: simpleId }));
    } catch (error) { console.error("Error crítico:", error); }
  };

  return (
    <div className="w-full h-full flex flex-col font-quicksand overflow-hidden bg-background-light">
        {firebaseError && (
          <div className="bg-red-600 text-white text-[10px] md:text-xs py-2 px-4 text-center font-black uppercase tracking-widest z-[200] flex flex-col items-center justify-center gap-1 shadow-2xl border-b-2 border-red-800">
            <div className="flex items-center gap-2"><span className="material-icons-round text-sm animate-pulse">error_outline</span>{firebaseError}</div>
          </div>
        )}

        {!['ADMIN_PANEL'].includes(state.step) && (
          <div className="w-full bg-primary h-16 md:h-20 flex items-center justify-center relative shrink-0 z-[60] shadow-md px-4">
             {config.appTheme.logoUrl ? <img src={config.appTheme.logoUrl} className="h-10 md:h-14 object-contain" alt="Logo" /> : <h2 className="font-display text-xl md:text-2xl text-white tracking-widest uppercase italic">{config.appTheme.brandName}</h2>}
          </div>
        )}

        <div className="flex-1 overflow-hidden flex flex-col relative">
            {state.step === 'SIZE' && <SizeStep selectedSize={state.selectedSize} onSelectSize={handleSelectSize} onNext={handleGoToFlavor} onAdminClick={handleGoToAdminLogin} config={config} />}
            {state.step === 'FLAVOR' && <FlavorStep {...state} onSelectFlavor={handleSelectFlavor} onSelectFilling={handleSelectFilling} onNext={handleGoToDecoration} onBack={handleGoToSize} onCustomFillingChange={handleCustomFillingChange} config={config} />}
            {state.step === 'DECORATION' && <DecorationStep {...state} onUpdateDecoration={handleUpdateDecoration} onNext={handleGoToPersonalization} onBack={handleGoToFlavor} config={config} />}
            {state.step === 'PERSONALIZATION' && <PersonalizationStep appState={state} onUpdate={handleUpdatePersonalization} onNext={handleGoToSummary} onBack={handleGoToDecoration} />}
            {state.step === 'SUMMARY' && <SummaryStep appState={state} onUpdate={handleUpdateSummary} onBack={handleGoToPersonalization} onConfirm={handleGoToPayment} config={config} />}
            {state.step === 'PAYMENT' && <PaymentStep {...state} config={config} onUpdatePayment={handleUpdatePayment} onBack={handleGoToSummary} onComplete={handleFinalizeOrder} />}
            {state.step === 'SUCCESS' && <SuccessStep orderId={state.lastOrderId || ''} onReset={resetApp} config={config} />}
            {state.step === 'ADMIN_LOGIN' && <AdminLogin onLoginSuccess={handleLoginSuccess} onCancel={resetApp} />}
            {state.step === 'ADMIN_PANEL' && (
              <div className="fixed inset-0 z-[100]">
                <AdminPanel 
                  config={config} 
                  onUpdateConfig={handleUpdateConfig} 
                  orders={orders} 
                  onDeleteOrder={handleDeleteOrder}
                  onUpdateOrderStatus={handleUpdateOrderStatus}
                  onClearOrders={() => {}} 
                  onExit={resetApp} 
                />
              </div>
            )}
        </div>
    </div>
  );
};

export default App;